@ TODO 
Verify dev, staging, and master exist
verify working on feature branch or similar
verify cannot push to staging or master (protected branches)