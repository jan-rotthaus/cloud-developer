import { FeedItem } from './feed/models/FeedItem';


export const V0_FEED_MODELS = [FeedItem];
